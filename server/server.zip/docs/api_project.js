define({
  "name": "express-rest-es2017-boilerplate",
  "version": "1.2.2",
  "description": "Express boilerplate for building RESTful APIs",
  "sampleUrl": false,
  "defaultVersion": "0.0.0",
  "apidoc": "0.3.0",
  "generator": {
    "name": "apidoc",
    "time": "2020-08-28T16:01:06.915Z",
    "url": "http://apidocjs.com",
    "version": "0.17.7"
  }
});
