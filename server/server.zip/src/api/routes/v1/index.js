const express = require('express');
const fitnessRoutes = require('./fitness.route');

const router = express.Router();

/**
 * GET v1/status
 */
router.get('/status', (req, res) => res.send('OK'));

/**
 * @request method api/v1/users, auth, public, provider,
 */

router.use('/fitness', fitnessRoutes);

router.get('/success' , (req ,res ) => {
    console.log('req.query'); 
    console.log(req.query); 
    return res.status(httpStatus.OK).json('ok');
})

router.get('/err' , (req , res) => {
    console.log('req.query'); 
    console.log(req.query); 
    return res.status(httpStatus.OK).json('error');
})

module.exports = router;
