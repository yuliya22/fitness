const express = require('express');
const router = express.Router();
const controller = require('../../controllers/fitness.controller');



router.route('/register')
  .post(controller.saveRegister);

router.route('/payment')
  .post(controller.payment);



module.exports = router;
