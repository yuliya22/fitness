export const environment = {
  production: true,
  domain: 'nemiac.com/',
  jitBaseUrl: 'pasatrae.com/',
  baseUrl: 'https://nemiac.com/api/v1/',
  socket_endpoint: 'https://nemiac.com',
  peerServerHost:'nemiac.com',
  peerServerPort:'9000',
  peerServerPath:'/peerjs'
};
