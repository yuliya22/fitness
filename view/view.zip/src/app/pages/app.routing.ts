import { Routes } from '@angular/router';
import {AuthGuard} from "../_helpers/auth.guard";
import { HomeComponent } from './home/home.component';
import {SignUpComponent} from './sign-up/sign-up.component';
import { PaymentComponent } from './payment/payment.component';
export const AppRoutes: Routes = [
  {
    path: '',
    redirectTo:'/home',
    pathMatch:'full'
    
  },
  {
    path: 'home',
    component:HomeComponent
  },
  {
    path: 'signUp',
    component:SignUpComponent
  },
  {
    path: 'payment',
    component:PaymentComponent
  },
  {
    path: 'super',
    redirectTo: 'auth',
    pathMatch: 'full'
  },

  {
    path: 'auth',
    loadChildren: () => import('./auth/auth.module').then(m => m.AuthModule)
  },

];


